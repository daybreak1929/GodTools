﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace GodTools.Code
{
    internal class Helper
    {
        private static Sprite window_inner_sliced;
        private static Sprite button;
        public static Sprite get_inner_sliced()
        {
            if(window_inner_sliced == null)
            {
                window_inner_sliced = GameObject.Find("Canvas Container Main/Canvas - Windows/windows/welcome/Background/BottomBg").GetComponent<Image>().sprite;
            }
            return window_inner_sliced;
        }
        public static Sprite get_button()
        {
            if (button == null)
            {
                button = CanvasMain.instance.canvas_ui.transform.Find("CanvasParent/CanvasRight/DebugButton").GetComponent<Image>().sprite;
            }
            return button;
        }
        public static void text_basic_setting(Text text)
        {
            text.font = LocalizedTextManager.currentFont;
            text.fontStyle = FontStyle.Bold;
            text.fontSize = 14;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMaxSize = 14;
            text.resizeTextMinSize = 2;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.text = "文本";
            text.color = new Color(1, 0.607f, 0.110f, 1);
        }
    }
}
