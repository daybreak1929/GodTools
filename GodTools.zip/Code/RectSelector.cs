﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace GodTools.Code
{
    internal class RectSelector : BaseWorldObject
    {
        SpriteRenderer spr;
        Vector2 start_pos;
        Vector2 cur_pos;
        bool start_to_select;
        bool is_working;
        float left_elapsed;
        bool initialized = false;
        void Awake()
        {
            if (!initialized)
            {
                initialized = true;
                initialize();
            }
        }

        public virtual void initialize()
        {
        }

        public virtual void start()
        {
            this.is_working = true;
            start_to_select = false;
            this.gameObject.SetActive(true);
            //rect = GetComponent<RectTransform>();
            spr = GetComponent<SpriteRenderer>();
            spr.sortingLayerName = "EffectsTop";
            spr.drawMode = SpriteDrawMode.Tiled;
            spr.size = new Vector2(0,0);
            this.transform.localScale = new Vector3(1, 1);
        }
        public override void onStart()
        {
            start_pos = Vector2.zero;
            cur_pos = Vector2.zero;
        }

        public void Update()
        {
            if (!this.is_working || left_elapsed>0) return;
            left_elapsed -= Time.deltaTime * C.rect_update_time_scale;
            if (Input.GetMouseButtonDown(0))
            {
                start_to_select = true;
                start_pos = World.world.getMousePos();
            }
            if (Input.GetMouseButton(0))
            {
                cur_pos = World.world.getMousePos();
                CreatRectangle(start_pos, cur_pos);
            }
            else if(start_to_select)
            {
                is_working = false;
                this.gameObject.SetActive(false);
            }
            Config.lockGameControls = this.is_working;
        }
        public virtual void CreatRectangle(Vector3 start, Vector3 end)
        {
            //rect.sizeDelta = new Vector2(Mathf.Abs(end.x - start.x), Mathf.Abs(end.y - start.y));
            //spr.size = new Vector2(Mathf.Abs(end.x - start.x), Mathf.Abs(end.y - start.y));
            /**
            spr.size = new Vector2(start.x - end.x, end.y - start.y)/2;
            this.transform.localScale = new Vector3(1, 1);
            this.transform.localPosition = new Vector3(start.x - spr.size.x, start.y)/2 - new Vector3(337, 136);
            */
            spr.size = new Vector2(start.x - end.x, end.y - start.y);
            this.transform.localScale = new Vector3(1, 1);
            this.transform.localPosition = new Vector3(start.x-spr.size.x/2f, start.y);
        }

        public virtual void finish()
        {
        }
    }
}
