﻿using ai.behaviours;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GodTools.Code
{
    internal class MyActorTasks
    {
        public static void init()
        {
            BehaviourTaskActor task;

            task = new BehaviourTaskActor();
            task.id = C.task_always_wait;
            task.addBeh(new BehAlwaysWait(5f));
            add(task);

            task = new BehaviourTaskActor();
            task.id = C.task_gt_fight;
            task.fighting = true;
            task.addBeh(new BehCheckGTFight());
            task.addBeh(new BehGoToActorTarget("sameTile", true));
            task.addBeh(new BehRestartTask());
            add(task);
        }
        private static void add(BehaviourTaskActor task) { AssetManager.tasks_actor.add(task); }
        class BehAlwaysWait : BehaviourActionActor
        {
            private float time;
            public BehAlwaysWait(float t) { time = t; }
            public override BehResult execute(Actor pObject)
            {
                pObject.timer_action = time;
                pObject.restoreHealth(Toolbox.randomInt(0, 3));
                return BehResult.RepeatStep;
            }
        }
        public class BehCheckGTFight : BehaviourActionActor
        {
            public static Actor target; 
            public override BehResult execute(Actor pActor)
            {
                if (target == null || !target.base_data.alive)
                {
                    target = null;
                    return BehResult.Stop;
                }
                if (!pActor.canAttackTarget(target))
                {
                    if(!pActor.targetsToIgnore.Contains(target)) pActor.targetsToIgnore.Add(target);
                    return BehResult.Stop;
                }
                pActor.attackTarget = target;
                pActor.beh_actor_target = target;
                //Main.log($"{pActor.getName()} Continue");
                return BehResult.Continue;
            }
        }
    }
}
