using System;
using NCMS;
using UnityEngine;
using ReflectionUtility;
using HarmonyLib;
using UnityEngine.UI;
using UnityEngine.Events;
namespace GodTools.Code
{
    public class Mod
    {
        public static ModDeclaration.Info Info;
        public static GameObject GameObject;
    }
    [ModEntry]
    class Main : MonoBehaviour{
        private bool initialized = false;
        private PosShowEffect last_pos_show;

        public PosShowEffect actor_select_effect;

        public static Main instance;
        public UnitsRectSelector rect_units_selector;
        public SimpleEffectController<PosShowEffect> pos_show_effect_controller = new SimpleEffectController<PosShowEffect>(Resources.Load<GameObject>("effects/PrefabUnitSelectionEffect"));
        public static void warn(string str)
        {
            UnityEngine.Debug.LogWarning($"[{Mod.Info.Name}]:{str}");
        }
        public static void log(string str)
        {
            UnityEngine.Debug.Log($"[{Mod.Info.Name}]:{str}");
        }
        void Update()
        {
            if (!initialized)
            {
                initialized = true;
                instance = this;
                foreach(NCMod mod in NCMS.ModLoader.Mods)
                {
                    if(mod.name == C.MOD_NAME)
                    {
                        Mod.Info = (ModDeclaration.Info)AccessTools.Constructor(typeof(ModDeclaration.Info), new Type[] { typeof(NCMod) }, false).Invoke(new object[] { mod });
                        Mod.GameObject = this.gameObject;
                        break;
                    }
                }

                AllPatch.patch_all(C.PATCH_ID);
                MyLocalizedTextManager.init();
                MyActorJobs.init();
                MyActorTasks.init();
                MyPowers.init();
                MyHotKeys.init();
                MyStatusEffects.init();
                MyTab.create_tab();
                MyTab.add_buttons();
                MyTab.apply_buttons();

                rect_units_selector = new GameObject("Rect Selector", typeof(UnitsRectSelector), typeof(SpriteRenderer)).GetComponent<UnitsRectSelector>();
                rect_units_selector.GetComponent<SpriteRenderer>().sprite = Resources.Load<Sprite>("gt_windows/white_block");
                rect_units_selector.GetComponent<SpriteRenderer>().color = new Color(0, 0.5f, 0.5f, 0.5f);
                rect_units_selector.gameObject.SetActive(false);

            }
            pos_show_effect_controller.update(Time.fixedDeltaTime * C.pos_show_effect_time_scale);

            if(actor_select_effect == null)
                actor_select_effect = pos_show_effect_controller.get(true);
            if (actor_select_effect_working())
            {
                actor_select_effect.left_time = 10;
                actor_select_effect.selected_actor = World.world.getActorNearCursor();
                if (actor_select_effect.selected_actor == null) actor_select_effect.set_active(false);
                else { actor_select_effect.set_active(); }
            }
            actor_select_effect.update(Time.fixedDeltaTime * C.pos_show_effect_time_scale);

            update_control();
        }
        private bool actor_select_effect_working()
        {
            return rect_units_selector.operate_key == C.attack_unit;
        }

        private void update_control()
        {
            if (MapBox.controlsLocked()) return;
            if (MapBox.isControllingUnit()) return;

            if (Input.GetMouseButtonDown(1))
            {
                switch (rect_units_selector.operate_key)
                {
                    case C.move_to_point:
                        {
                            if (!Input.GetKey(KeyCode.LeftControl) && !Input.GetKey(KeyCode.LeftCommand)) break;
                            WorldTile tile = World.world.getMouseTilePos();
                            if (tile == null) break;
                            foreach(Actor unit in rect_units_selector.active_units_stack)
                            {
                                unit.cancelAllBeh(null);
                                unit.attackTarget = null;
                                unit.goTo(tile);
                            }
                            if (last_pos_show != null) last_pos_show.stop();
                            last_pos_show = pos_show_effect_controller.get();
                            last_pos_show.show(tile.posV3, time: 5);
                            break;
                        }
                    case C.attack_unit:
                        {
                            if (!Input.GetKey(KeyCode.LeftControl) && !Input.GetKey(KeyCode.LeftCommand)) break;
                            Actor target = World.world.getActorNearCursor();

                            if(target == null) break;
                            MyActorTasks.BehCheckGTFight.target = target;
                            foreach (Actor unit in rect_units_selector.active_units_stack)
                            {
                                unit.cancelAllBeh(null);
                                unit.ai.setJob(C.attack_unit);
                            }

                            target.addStatusEffect(C.attack_unit);

                            if (last_pos_show != null) last_pos_show.stop();
                            last_pos_show = pos_show_effect_controller.get();
                            last_pos_show.show(target, target.currentScale, 1);
                            break;
                        }
                    default:
                        return;
                }
            }
        }
    }
}