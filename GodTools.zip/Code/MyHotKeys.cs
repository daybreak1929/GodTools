﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GodTools.Code
{
    internal class MyHotKeys
    {
        public static void init()
        {

        }
    }
}
