﻿using DG.Tweening;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.UI;

namespace GodTools.Code
{
    internal class Controller : MonoBehaviour
    {
        public Image icon;
        public Image bg;
        public Button main_button;
        public List<Button> buttons = new List<Button>();
        public bool is_showing = false;
        public static GameObject button_prefab;
        public void create(string name, Sprite icon_sprite, List<Controller> controllers, string title_key, string desc_key)
        {
            this.gameObject.name = name;
            this.bg = this.transform.Find("Controller BG").GetComponent<Image>();
            this.icon = this.transform.Find("Controller Button").GetComponent<Image>();
            this.main_button = this.transform.Find("Controller Button").GetComponent<Button>();

            Image cancel_button_image = CanvasMain.instance.canvas_ui.transform.Find("CanvasParent/CanvasLeft/SideCenterLeft/CancelButtonMover/CancelButton/Icon").GetComponent<Image>();

            this.main_button.onClick.AddListener(new UnityEngine.Events.UnityAction(() =>
            {
                if (is_showing)
                {
                    hide();
                    return;
                }
                foreach (Controller controller in controllers) controller.hide();
                show();
                cancel_button_image.sprite = this.icon.sprite;
            }));
            TipButton tip_button = this.transform.Find("Controller Button").GetComponent<TipButton>();
            tip_button.textOnClick = title_key;
            tip_button.textOnClickDescription = desc_key;

            this.bg.gameObject.SetActive(false);
            this.icon.sprite = icon_sprite;
            this.icon.transform.localScale = new Vector3(1, 1);
            this.icon.transform.localPosition = new Vector3(0, 0);
            RectTransform rect = icon.GetComponent<RectTransform>();
            rect.sizeDelta = new Vector2(50, 50);
            this.bg.transform.position = new Vector3(210, 638.4f);
            this.bg.GetComponent<RectTransform>().sizeDelta = new Vector2(36, 0);
        }
        public void add_button(GameObject button)
        {
            button.transform.SetParent(this.bg.transform);
            button.transform.localScale = new Vector3(1, 1);
            this.bg.GetComponent<RectTransform>().sizeDelta = new Vector2(36, this.bg.transform.childCount*46);
        }
        public void hide()
        {
            if (!is_showing) return;
            is_showing = false;
            this.bg.gameObject.SetActive(false);
        }
        public void show()
        {
            if (is_showing) return;
            is_showing = true;
            this.bg.gameObject.SetActive(true);
            this.bg.transform.position = new Vector3(210, 638.4f);
        }
    }
    internal class UnitsRectSelector : RectSelector
    {
        Stack<Actor> __units_stack_1 = new Stack<Actor>();
        Stack<Actor> __units_stack_2 = new Stack<Actor>();
        public List<Actor> active_units_stack = new List<Actor>();
        Stack<Actor> inactive_units_stack;
        bool to_operate_on_units = false;
        GameObject operate_console;
        public string operate_key { get; private set; }
        public override void start()
        {
            base.start();
            __units_stack_1.Clear();
            __units_stack_2.Clear();
            to_operate_on_units = false;
            //active_units_stack = __units_stack_1;
            //inactive_units_stack = __units_stack_2;
            Main.instance.pos_show_effect_controller.inactive_all();
        }
        public override void CreatRectangle(Vector3 start, Vector3 end)
        {
            base.CreatRectangle(start, end);
            active_units_stack.Clear();
            if(!to_operate_on_units) prepare_operate_on_units();
            Main.instance.pos_show_effect_controller.inactive_all();
            int x_off = end.x >= start.x ? 1 : -1;
            int y_off = end.y >= start.y ? 1 : -1;
            int start_x = (int)start.x;
            int start_y = (int)start.y;
            int len_x = Math.Abs((int)end.x - start_x);
            int len_y = Math.Abs((int)end.y - start_y);
            for(int i=0; i < len_x; i++)
            {
                for(int j=0; j < len_y; j ++)
                {
                    WorldTile tile = World.world.GetTile(start_x +i*x_off, start_y+j*y_off);

                    if (tile == null) continue;
                    active_units_stack.AddRange(tile._units);
                    tile.doUnits(show_pos_for_unit);
                }
            }
        }

        private void prepare_operate_on_units()
        {
            to_operate_on_units = true;
            operate_console.SetActive(true);
        }
        public override void finish()
        {
            base.finish();
            active_units_stack.Clear();
            operate_console.SetActive(false);
            Main.instance.pos_show_effect_controller.inactive_all();
        }

        private void show_pos_for_unit(Actor actor)
        {
            Main.instance.pos_show_effect_controller.get().show(actor, actor.currentScale, 600);
        }

        public override void initialize()
        {
            base.initialize();
            operate_console = new GameObject("Console");
            operate_console.SetActive(false);
            operate_console.transform.SetParent(CanvasMain.instance.canvas_ui.transform.Find("CanvasParent"));
            operate_console.transform.localScale = new Vector3(1, 1);
            operate_console.transform.localPosition = new Vector3(-400, 212);

            GameObject console_icon = new GameObject("Console Icon", typeof(Image), typeof(Button));
            console_icon.transform.SetParent(operate_console.transform);
            console_icon.transform.localScale = new Vector3(1, 1);
            console_icon.transform.localPosition = new Vector3(0, 0);
            console_icon.GetComponent<Image>().sprite = Resources.Load<Sprite>("gt_windows/icon");
            
            console_icon.GetComponent<Button>().onClick.AddListener(new UnityEngine.Events.UnityAction(() =>
            {
                start();
                console_icon.transform.localScale = new Vector3(1.2f, 1.2f);
                console_icon.transform.DOKill(false);
                console_icon.transform.DOScale(1, 0.1f).SetEase(Ease.InBack);
            }));
            Controller controller_prefab = new GameObject("Controller", typeof(Controller)).GetComponent<Controller>();
            GameObject __controller_button = new GameObject("Controller Button", typeof(Image), typeof(Button), typeof(TipButton));
            __controller_button.transform.SetParent(controller_prefab.transform);
            Image __controller_bg = new GameObject("Controller BG", typeof(Image), typeof(GridLayoutGroup)).GetComponent<Image>();
            __controller_bg.sprite = Helper.get_button();
            __controller_bg.type = Image.Type.Sliced;
            __controller_bg.transform.SetParent(controller_prefab.transform);
            GridLayoutGroup __controller_layout_group = __controller_bg.GetComponent<GridLayoutGroup>();
            __controller_layout_group.cellSize = new Vector2(36, 36);
            __controller_layout_group.spacing = new Vector2(0, 10);
            __controller_layout_group.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            __controller_layout_group.constraintCount = 1;

            Controller.button_prefab = new GameObject("Button", typeof(Image), typeof(Button), typeof(TipButton));
            Controller.button_prefab.GetComponent<TipButton>().textOnClick = C.success;


            Controller job_controller = GameObject.Instantiate(controller_prefab, operate_console.transform);
            Controller action_controller = GameObject.Instantiate(controller_prefab, operate_console.transform);
            Controller attack_controller = GameObject.Instantiate(controller_prefab, operate_console.transform);

            List<Controller> controllers = new List<Controller>() { attack_controller, action_controller, job_controller };
            job_controller.create(C.job_controller, Resources.Load<Sprite>("ui/icons/iconPopulation"), controllers, C.job_controller_title, C.job_controller_desc);
            action_controller.create(C.action_controller, Resources.Load<Sprite>("ui/icons/items/icon_boots_mythril"), controllers, C.action_controller_title, C.action_controller_desc);
            attack_controller.create(C.attack_controller, Resources.Load<Sprite>("ui/icons/iconDamage"), controllers, C.attack_controller_title, C.attack_controller_desc);

            Vector3 interval_vec = new Vector3(0, -70);
            attack_controller.transform.localPosition = interval_vec;
            action_controller.transform.localPosition = attack_controller.transform.localPosition + interval_vec;
            job_controller.transform.localPosition = action_controller.transform.localPosition + interval_vec;

            Image cancel_button_image = CanvasMain.instance.canvas_ui.transform.Find("CanvasParent/CanvasLeft/SideCenterLeft/CancelButtonMover/CancelButton/Icon").GetComponent<Image>();

            GameObject move_to_point_buttoon = Instantiate(Controller.button_prefab);
            init_ctrl_button(move_to_point_buttoon, "gt_windows/move_to_point", C.move_to_point, () =>
            {
                operate_key = C.move_to_point;
                cancel_button_image.sprite = move_to_point_buttoon.GetComponent<Image>().sprite;
            });
            action_controller.add_button(move_to_point_buttoon);

            GameObject wait_button = Instantiate(Controller.button_prefab);
            init_ctrl_button(wait_button, "gt_windows/wait_for_cmd", C.wait, () =>
            {
                foreach (Actor unit in active_units_stack)
                {
                    unit.cancelAllBeh(null);
                    unit.ai.setJob(C.wait);
                }
            });
            action_controller.add_button(wait_button);

            GameObject attack_unit_button = Instantiate(Controller.button_prefab);
            init_ctrl_button(attack_unit_button, "gt_windows/attack_unit", C.attack_unit, () =>
            {
                operate_key = C.attack_unit;
                cancel_button_image.sprite = attack_unit_button.GetComponent<Image>().sprite;
            });
            attack_controller.add_button(attack_unit_button);
        }
        private void init_ctrl_button(GameObject button, string sprite_path, string name, UnityEngine.Events.UnityAction action)
        {
            button.name = name;
            button.GetComponent<Image>().sprite = Resources.Load<Sprite>(sprite_path);
            button.GetComponent<Button>().onClick.AddListener(action);
            if (LocalizedTextManager.stringExists(name + C.title_postfix))
                button.GetComponent<TipButton>().textOnClick = name + C.title_postfix;
            if (LocalizedTextManager.stringExists(name + C.desc_postfix)) button.GetComponent<TipButton>().textOnClickDescription = name + C.desc_postfix;
        }
    }
}
