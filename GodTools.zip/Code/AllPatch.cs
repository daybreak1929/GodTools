﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HarmonyLib;
namespace GodTools.Code
{
    internal static class AllPatch
    {
        public static void patch_all(string id)
        {
            Harmony.CreateAndPatchAll(typeof(AllPatch), id);
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(CultureWindow), "OnEnable")]
        public static void culture_tech_editor_init(CultureWindow __instance)
        {
            WindowCultureTechEditor.init(__instance);
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(WindowCreatureInfo), "OnEnable")]
        public static void status_effect_editor_init(WindowCreatureInfo __instance)
        {
            WindowStatusEffectEditor.init(__instance);
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(WindowCreatureInfo), "OnEnable")]
        public static void item_editor_init(WindowCreatureInfo __instance)
        {
            if (Config.selectedUnit.asset.use_items)
            {
                WindowItemEditor.init(__instance);
                WindowItemEditor.entry_button.SetActive(true);
            }
            else if (WindowItemEditor.entry_button != null)
            {
                WindowItemEditor.entry_button.SetActive(false);
            }
        }
        [HarmonyPostfix]
        [HarmonyPatch(typeof(PowerButton), nameof(PowerButton.unselectActivePower))]
        public static void post_poweraction(PowerButton __instance)
        {
            PowerButtonClickAction action;
            if(MyPowers.post_actions.TryGetValue(__instance.godPower.id, out action))
            {
                action(__instance.godPower.id);
            }
        }
    }
}
